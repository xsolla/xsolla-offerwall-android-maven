package com.xsolla.android.mobile.offerwall.webview.configs

import android.os.Parcelable
import kotlinx.parcelize.Parcelize

/**
 * What content to load in the WebView.
 */
@Parcelize
internal sealed class WebViewContentConfig : Parcelable {
    /**
     * Loads content from URL.
     */
    @Parcelize
    data class Url(
        val url: String,
        val headers: Map<String, String> = emptyMap()
    ) : WebViewContentConfig()
}
