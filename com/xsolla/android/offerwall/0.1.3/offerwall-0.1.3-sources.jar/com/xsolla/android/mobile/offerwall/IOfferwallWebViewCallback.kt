package com.xsolla.android.mobile.offerwall

import com.xsolla.android.mobile.Either
import com.xsolla.android.mobile.Error

internal interface IOfferwallWebViewCallback {
    fun onOpened()
    fun onClosed()
    fun onError(err: Error)
}