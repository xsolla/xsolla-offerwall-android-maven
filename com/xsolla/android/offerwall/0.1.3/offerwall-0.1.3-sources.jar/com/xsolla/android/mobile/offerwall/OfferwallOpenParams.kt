package com.xsolla.android.mobile.offerwall

class OfferwallOpenParams private constructor(
    val placementId: String?,
    val userId: String?,
    val customParams: CustomParams?
) {
    class CustomParams private constructor(
       internal val params: List<Param>?
    ) {
        class Builder {
            private var params: MutableList<Param>? = null

            @JvmOverloads
            fun addParam(key: String, value: String? = null) = apply {
                require(!key.isBlank()) { "Parameter key cannot be empty" }

                params = params ?: mutableListOf()

                val index = params!!.indexOfFirst { param -> param.key == key }
                if (index == -1) {
                    params!!.add(Param(key, value))
                } else {
                    params!![index] = Param(key, value)
                }
            }

            fun build(): CustomParams {
                return CustomParams(params)
            }
        }

        internal data class Param(val key: String, val value: String?)
    }

    class Builder {
        private var placementId: String? = null
        private var userId: String? = null
        private var customParams: CustomParams? = null

        fun withPlacementId(placementId: String?) = apply {
            this.placementId = placementId
        }

        fun withUserId(userId: String?) = apply {
            this.userId = userId
        }

        fun withCustomParams(customParams: CustomParams?) = apply {
            this.customParams = customParams
        }

        fun build(): OfferwallOpenParams {
            return OfferwallOpenParams(placementId, userId, customParams)
        }
    }
}
