package com.xsolla.android.mobile.offerwall

import android.app.Activity
import com.xsolla.android.mobile.Either
import com.xsolla.android.mobile.Error
import com.xsolla.android.mobile.offerwall.webview.WebViewActivity
import com.xsolla.android.mobile.offerwall.webview.WebViewManager
import android.content.pm.ActivityInfo
import com.xsolla.android.mobile.offerwall.webview.configs.WebViewBehaviorConfig
import com.xsolla.android.mobile.offerwall.webview.configs.WebViewConfig
import com.xsolla.android.mobile.offerwall.webview.configs.WebViewContentConfig
import com.xsolla.android.mobile.offerwall.webview.configs.WebViewInterceptionConfig
import com.xsolla.android.mobile.offerwall.webview.configs.WebViewLifecycleConfig
import com.xsolla.android.mobile.offerwall.webview.configs.WebViewSplashConfig
import com.xsolla.android.mobile.offerwall.webview.configs.WebViewSplashTransitionConfig
import com.xsolla.android.mobile.offerwall.webview.configs.WebViewThemeColors
import com.xsolla.android.mobile.offerwall.webview.configs.WebViewThemeConfig

internal object OfferwallWebViewEmbedded : IOfferwallWebView {
    override fun open(
        activity: Activity,
        url: String,
        settings: OfferwallClientSettings,
        callback: IOfferwallWebViewCallback
    ) {
        WebViewActivity.start(
            context = activity, config = WebViewConfig(
                content = WebViewContentConfig.Url(url),
                splash = settings.splash?.let {
                    when (it.type) {
                        OfferwallClientSettings.SplashType.Synchronous ->
                            WebViewSplashConfig.Synchronous(
                                drawable = it.drawable,
                                backgroundColor = it.backgroundColor,
                                durationMillis = it.durationMillis,
                                transition = when (val transition = it.transition) {
                                    OfferwallClientSettings.SplashTransition.Immediate ->
                                        WebViewSplashTransitionConfig.Immediate
                                    is OfferwallClientSettings.SplashTransition.Animated ->
                                        WebViewSplashTransitionConfig.Animated(
                                            fadeInDuration = transition.durationMillis
                                        )
                                }
                            )
                        OfferwallClientSettings.SplashType.Parallel ->
                            WebViewSplashConfig.Parallel(
                                drawable = it.drawable,
                                backgroundColor = it.backgroundColor,
                                minDurationMillis = it.durationMillis,
                                transition = when (val transition = it.transition) {
                                    OfferwallClientSettings.SplashTransition.Immediate ->
                                        WebViewSplashTransitionConfig.Immediate
                                    is OfferwallClientSettings.SplashTransition.Animated ->
                                        WebViewSplashTransitionConfig.Animated(
                                            fadeInDuration = transition.durationMillis
                                        )
                                }
                            )
                    }
                },
                theme = when (val theme = settings.theme) {
                    OfferwallClientSettings.Theme.System ->
                        WebViewThemeConfig.System
                    is OfferwallClientSettings.Theme.Custom ->
                        WebViewThemeConfig.Manual(
                            WebViewThemeColors(
                                statusBarColor = theme.colors.statusBarColor,
                                navigationBarColor = theme.colors.navigationBarColor
                            )
                        )
                },
                lifecycle = WebViewLifecycleConfig(
                    keepAlive = false
                ),
                behavior = WebViewBehaviorConfig(
                    allowBackNavigation = true,
                    showLoadingProgress = false,
                    enableJavaScript = true,
                    enableDomStorage = true,
                    allowFileAccess = false
                ),
                activityTransition = settings.useOpenAnimation,
                screenOrientation = when (settings.orientation) {
                    OfferwallClientSettings.Orientation.Portrait ->
                        ActivityInfo.SCREEN_ORIENTATION_PORTRAIT
                    OfferwallClientSettings.Orientation.Landscape ->
                        ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE
                    OfferwallClientSettings.Orientation.Unspecified ->
                        ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
                },
                interception = WebViewInterceptionConfig(
                    interceptExternalLinks = settings.openExternalLinksInBrowser,
                    interceptMailtoLinks = settings.openExternalLinksInBrowser,
                    interceptTelLinks = settings.openExternalLinksInBrowser
                ),
                openedCallback = { callback.onOpened() },
                closedCallback = { callback.onClosed() },
                errorCallback = { callback.onError(it) }
            )
        )
    }

    override fun shutdown() {
        WebViewManager.invalidate()
    }
}