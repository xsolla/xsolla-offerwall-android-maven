package com.xsolla.android.mobile.offerwall

import android.app.Activity

internal interface IOfferwallWebView {
    fun open(
        activity: Activity,
        url: String,
        settings: OfferwallClientSettings,
        callback: IOfferwallWebViewCallback
    )

    fun shutdown()
}