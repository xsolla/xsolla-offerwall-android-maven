package com.xsolla.android.mobile.offerwall

import android.app.Activity
import com.xsolla.android.mobile.Either
import com.xsolla.android.mobile.Error
import com.xsolla.android.mobile.offerwall.util.DeviceIdProvider
import com.xsolla.android.mobile.offerwall.util.Logger
import com.xsolla.android.mobile.offerwall.util.MainThreadScheduler
import java.util.Optional
import java.util.concurrent.CompletableFuture
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors
import java.util.concurrent.ThreadFactory
import java.util.concurrent.atomic.AtomicInteger
import androidx.core.net.toUri

class OfferwallClient private constructor(
    private val settings: OfferwallClientSettings
) {
    /** A lock used to synchronize the state of the client between threads. */
    private val lock = Any()

    @Volatile
    private var state: OfferwallClientState = OfferwallClientState.Disconnected

    private val executorService: ExecutorService by lazy {
        Executors.newFixedThreadPool(
            Runtime.getRuntime().availableProcessors(),
            CustomThreadFactory(threadPrefix = TAG)
        )
    }

    init {
        Logger.setLevel(settings.logLevel)
    }

    fun connect(callback: (Either<Error, Void>) -> Unit) {
        connect(object : IOfferwallClientConnectCallback {
            override fun onCallback(result: Either<Error, Void>) {
                callback(result)
            }
        })
    }

    fun connect(callback: IOfferwallClientConnectCallback) {
        synchronized(lock) {
            if (isReady()) {
                Logger.warn("Client has already been connected")

                MainThreadScheduler.schedule {
                    callback.onCallback(Either.rightUnit())
                }
            } else if (state == OfferwallClientState.Disconnected) {
                Logger.info("Client has started the connection process")

                state = OfferwallClientState.Connecting

                CompletableFuture.runAsync(
                    {
                        synchronized(lock) {
                            val either = Either.ofBoolean(
                                state == OfferwallClientState.Connecting,
                                {
                                    if (state == OfferwallClientState.Closed) Optional.empty()
                                    else Optional.of(Error.of(
                                        "Tried to connect while in a wrong state ($state)"
                                    ))
                                },
                                { Unit }
                            )

                            val maybeResult: Optional<Either<Error, Void>> = either.fold(
                                { maybeError ->
                                    if (maybeError.isPresent) {
                                        Optional.of(Either.left(maybeError.get()))
                                    } else {
                                        // Don't invoke the callback.
                                        Optional.empty()
                                    }
                                },
                                {
                                    state = OfferwallClientState.Connected(
                                        when (settings.activity ?: OfferwallClientSettings.Activity.Embedded) {
                                            OfferwallClientSettings.Activity.Embedded ->
                                                OfferwallWebViewEmbedded
                                        }
                                    )

                                    Logger.info("Client has successfully connected")

                                    Optional.of(Either.rightUnit())
                                }
                            )

                            maybeResult.ifPresent {
                                MainThreadScheduler.schedule {
                                    callback.onCallback(it)
                                }
                            }
                        }
                    },
                    executorService
                )
            }
        }
    }

    fun shutdown() {
        val executorService: ExecutorService

        synchronized(lock) {
            val state = this.state

            if (!(state == OfferwallClientState.Closed || state == OfferwallClientState.Disconnected)) {
                if (state is OfferwallClientState.Connected) {
                    val webView = state.webView
                    MainThreadScheduler.schedule {
                        webView.shutdown()
                    }
                }

                this.state = OfferwallClientState.Closed

                Logger.info("Client has been shutdown")
            }

            executorService = this.executorService
        }

        executorService.shutdownNow()
    }

    @JvmOverloads
    fun open(
        activity: Activity,
        params: OfferwallOpenParams? = null,
        callback: IOfferwallOpenCallback
    ): Either<Error, Void> {
        if (state !is OfferwallClientState.Connected) {
            return Either.left(Error.of(
                "Offerwall cannot be opened because the client is either " +
                "still still connecting, disconnected or closed"
            ))
        }

        val placementId = params?.placementId ?: settings.placementId
        if (placementId.isNullOrBlank()) {
            return Either.left(Error.of(
                "Opening offerwall requires a valid placement ID"
            ))
        }

        val userId = params?.userId ?: settings.userId
        if (userId.isNullOrBlank()) {
            return Either.left(Error.of(
                "Opening offerwall requires a valid user ID"
            ))
        }

        Logger.info("Opening an offerwall (placement_id=$placementId user_id=$userId)")

        val future = CompletableFuture<Either<Error, Void>>()

        future.thenAcceptAsync(
            {
                MainThreadScheduler.schedule {
                    callback.onCallback(it)
                }
            },
            executorService
        )

        CompletableFuture.runAsync(
            {
                val state = this.state
                if (state !is OfferwallClientState.Connected) {
                    future.complete(Either.left(Error.of(
                        "Tried to open an offerwall, but the client is in a wrong state (" +
                        "placement_id=$placementId user_id=$userId state=$state)"
                    )))
                } else {
                    val deviceIds = DeviceIdProvider.resolve(activity.applicationContext)

                    val url = BASE_URL.toUri()
                        .buildUpon()
                        .appendPath(placementId)
                        .appendQueryParameter("gamer_id", userId)
                        .appendQueryParameter("platform", "android")
                        .apply {
                            params?.customParams?.let {
                                if (!it.params.isNullOrEmpty()) {
                                    it.params.forEach { (key, value) ->
                                        if (value != null) {
                                            appendQueryParameter(key, value)
                                        } else {
                                            encodedQuery(
                                                listOfNotNull(build().encodedQuery, key)
                                                    .joinToString("&")
                                            )
                                        }
                                    }
                                }
                            }
                            deviceIds.androidId?.let { appendQueryParameter("device_id", it) }
                            deviceIds.advertisingId?.let { appendQueryParameter("advertising_id", it) }
                            settings.privacyPolicy?.let { privacy ->
                                privacy.subjectToGDPR?.let { appendQueryParameter("gdpr_applicable", if (it) "1" else "0") }
                                privacy.userConsent?.let { appendQueryParameter("user_consent", it) }
                                privacy.belowConsentAge?.let { appendQueryParameter("below_consent_age", if (it) "1" else "0") }
                                privacy.usPrivacy?.let { appendQueryParameter("us_privacy", it) }
                            }
                        }
                        .build()

                    Logger.debug("Offerwall URL: $url")

                    MainThreadScheduler.schedule {
                        state.webView.open(activity, url.toString(), settings, object : IOfferwallWebViewCallback {
                            override fun onOpened() {
                                Logger.debug("Opened the oferwall webview")
                            }

                            override fun onClosed() {
                                Logger.debug("Closed the offerwall webview")

                                MainThreadScheduler.schedule {
                                    callback.onCallback(Either.rightUnit())
                                }
                            }

                            override fun onError(err: Error) {
                                Logger.errorD(err)

                                MainThreadScheduler.schedule {
                                    callback.onCallback(Either.left(err))
                                }
                            }
                        })
                    }
                }
            },
            executorService
        )

        return Either.rightUnit()
    }

    /**
     * Opens an offerwall.
     *
     * @param params Various parameters related to opening an offerwall (`null` if defaults
     *   from [OfferwallClientSettings] should be used instead, but make sure they are
     *   configured then)
     * @param callback Callback to invoke when the offerwall gets closed.
     *
     * @return The result of opening the offerwall.
     */
    fun open(
        activity: Activity,
        params: OfferwallOpenParams? = null,
        callback: (Either<Error, Void>) -> Unit
    ): Either<Error, Void> {
        return open(activity, params, object : IOfferwallOpenCallback {
            override fun onCallback(result: Either<Error, Void>) {
                callback(result)
            }
        })
    }

    fun isReady(): Boolean = state is OfferwallClientState.Connected

    class Builder {
        private var settings: OfferwallClientSettings? = null

        fun withSettings(settings: OfferwallClientSettings) = apply {
            this.settings = settings
        }

        fun build() : OfferwallClient {
            require(settings != null) {
                "Offerwall client settings are missing"
            }

            return OfferwallClient(settings!!)
        }
    }

    private class CustomThreadFactory(val threadPrefix: String) : ThreadFactory {
        private val factoryImpl: ThreadFactory = Executors.defaultThreadFactory()
        private val nextThreadId: AtomicInteger = AtomicInteger(1)

        override fun newThread(r: Runnable?): Thread? {
            val thread = factoryImpl.newThread(r)
            val threadId = nextThreadId.getAndIncrement()
            val threadName = (if (threadPrefix.isBlank()) "" else "-$threadPrefix") + threadId
            thread.setName(threadName)
            return thread
        }
    }

    companion object {
        private const val TAG: String = "XsollaOfferwallSDK"

        private const val BASE_URL = "https://quests.xsolla.com/offerwall/"
    }
}