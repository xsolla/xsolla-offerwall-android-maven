package com.xsolla.android.mobile.offerwall.webview.configs

import android.os.Parcelable
import kotlinx.parcelize.Parcelize

/**
 * Theme and color configuration.
 */
@Parcelize
internal sealed class WebViewThemeConfig : Parcelable {
    /**
     * Manual theme colors (no auto-detection).
     */
    @Parcelize
    data class Manual(val colors: WebViewThemeColors) : WebViewThemeConfig()

    /**
     * No theme customization (use system defaults).
     */
    @Parcelize
    data object System : WebViewThemeConfig()
}
