package com.xsolla.android.mobile.offerwall.util

import android.annotation.SuppressLint
import android.content.Context
import android.provider.Settings

/**
 * Resolves device identifiers for ad attribution.
 *
 * - **Android ID** (IDFV equivalent): always available via [Settings.Secure.ANDROID_ID].
 * - **Google Advertising ID** (IDFA equivalent): resolved via reflection so that
 *   `play-services-ads-identifier` remains an optional dependency. Returns `null` when
 *   Play Services is absent, the user has opted out of ad tracking, or any error occurs.
 *
 * Must be called on a **background thread** (the GAID lookup is an IPC call).
 */
internal data class DeviceIdentifiers(
    val androidId: String?,
    val advertisingId: String?
)

internal object DeviceIdProvider {

    @SuppressLint("HardwareIds")
    fun resolve(context: Context): DeviceIdentifiers {
        val androidId = try {
            Settings.Secure.getString(context.contentResolver, Settings.Secure.ANDROID_ID)
        } catch (e: Exception) {
            Logger.warn(e, "Failed to retrieve Android ID")
            null
        }

        val advertisingId = resolveAdvertisingId(context)

        Logger.debug("Resolved device identifiers: android_id=${androidId != null} advertising_id=${advertisingId != null}")

        return DeviceIdentifiers(androidId, advertisingId)
    }

    private fun resolveAdvertisingId(context: Context): String? {
        return try {
            val clientClass = Class.forName("com.google.android.gms.ads.identifier.AdvertisingIdClient")
            val getInfoMethod = clientClass.getMethod("getAdvertisingIdInfo", Context::class.java)
            val adInfo = getInfoMethod.invoke(null, context)

            val infoClass = adInfo.javaClass
            val isLimitedMethod = infoClass.getMethod("isLimitAdTrackingEnabled")
            val isLimited = isLimitedMethod.invoke(adInfo) as Boolean

            if (isLimited) {
                Logger.debug("User has opted out of ad tracking, skipping advertising ID")
                return null
            }

            val getIdMethod = infoClass.getMethod("getId")
            getIdMethod.invoke(adInfo) as? String
        } catch (e: ClassNotFoundException) {
            Logger.debug("Play Services ads-identifier not available, skipping advertising ID")
            null
        } catch (e: Exception) {
            Logger.warn(e, "Failed to retrieve Google Advertising ID")
            null
        }
    }
}
