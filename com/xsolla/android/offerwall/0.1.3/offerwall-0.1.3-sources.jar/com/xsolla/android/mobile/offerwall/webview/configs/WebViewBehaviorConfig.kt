package com.xsolla.android.mobile.offerwall.webview.configs

import android.os.Parcelable
import kotlinx.parcelize.Parcelize

/**
 * WebView interaction behavior.
 */
@Parcelize
internal data class WebViewBehaviorConfig(
    val allowBackNavigation: Boolean = true,
    val showLoadingProgress: Boolean = true,
    val enableJavaScript: Boolean = true,
    val enableDomStorage: Boolean = true,
    val allowFileAccess: Boolean = false
) : Parcelable
