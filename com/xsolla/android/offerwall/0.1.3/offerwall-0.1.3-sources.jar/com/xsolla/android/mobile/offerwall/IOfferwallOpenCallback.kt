package com.xsolla.android.mobile.offerwall

import com.xsolla.android.mobile.Either
import com.xsolla.android.mobile.Error

interface IOfferwallOpenCallback {
    fun onCallback(result: Either<Error, Void>)
}