package com.xsolla.android.mobile.offerwall.webview.util

import android.graphics.Bitmap
import android.graphics.Color
import android.util.Log
import androidx.annotation.ColorInt
import androidx.core.graphics.ColorUtils
import androidx.palette.graphics.Palette
import kotlin.math.max

/**
 * Utility for extracting colors from various sources.
 */
internal object ColorUtil {
    private const val TAG = "ColorExtractor"

    /**
     * Extracts dominant color from bitmap using Palette API.
     *
     * @param bitmap The bitmap to extract color from.
     * @param fallback The fallback color if extraction fails.
     *
     * @return The extracted color or fallback.
     */
    @ColorInt
    fun getDominantColor(bitmap: Bitmap, @ColorInt fallback: Int): Int {
        return runCatching {
            val palette = Palette.from(bitmap).generate()

            palette.dominantSwatch?.rgb
                ?: palette.vibrantSwatch?.rgb
                ?: palette.mutedSwatch?.rgb
                ?: palette.lightVibrantSwatch?.rgb
                ?: palette.darkMutedSwatch?.rgb
                ?: fallback
        }.getOrElse {
            Log.e(TAG, "Error extracting dominant color", it)
            fallback
        }
    }

    /**
     * Extracts best color for status bar from top portion of bitmap.
     *
     * @param screenshot The screenshot to extract from.
     * @param fallback The fallback color if extraction fails.
     *
     * @return The extracted color or fallback.
     */
    @ColorInt
    fun getStatusBarColor(screenshot: Bitmap, @ColorInt fallback: Int): Int =
        extractColorFromSection(
            screenshot = screenshot,
            sectionPercent = 0.1f,
            fromTop = true,
            fallback = fallback
        )

    /**
     * Extracts best color for navigation bar from bottom portion of bitmap.
     *
     * @param screenshot The screenshot to extract from.
     * @param fallback The fallback color if extraction fails.
     *
     * @return The extracted color or fallback.
     */
    @ColorInt
    fun getNavigationBarColor(screenshot: Bitmap, @ColorInt fallback: Int): Int =
        extractColorFromSection(
            screenshot = screenshot,
            sectionPercent = 0.1f,
            fromTop = false,
            fallback = fallback
        )

    /**
     * Extracts color from a specific section of the bitmap.
     *
     * @param screenshot The bitmap to extract from.
     * @param sectionPercent The percentage of the bitmap to analyze.
     * @param fromTop True to extract from top, false for bottom.
     * @param fallback The fallback color if extraction fails.
     *
     * @return The extracted color or fallback.
     */
    private fun extractColorFromSection(
        screenshot: Bitmap,
        sectionPercent: Float,
        fromTop: Boolean,
        @ColorInt fallback: Int
    ): Int {
        return runCatching {
            val height = max(1, (screenshot.height * sectionPercent).toInt())
            val startY = if (fromTop) 0 else screenshot.height - height

            val section = Bitmap.createBitmap(
                screenshot,
                0,
                startY,
                screenshot.width,
                height
            )

            val palette = Palette.from(section).generate()
            val color = palette.dominantSwatch?.rgb ?: fallback

            section.recycle()
            color
        }.getOrElse {
            Log.e(TAG, "Error extracting section color", it)
            fallback
        }
    }

    /**
     * Gets comprehensive color profile from bitmap.
     *
     * @param screenshot The bitmap to analyze.
     *
     * @return ColorProfile with all available colors.
     */
    fun getColorProfile(screenshot: Bitmap): ColorProfile {
        return ColorProfile(runCatching {
            Palette.from(screenshot).generate()
        }.getOrElse {
            Log.e(TAG, "Error generating color profile", it)
            null
        })
    }

    /**
     * Determines if a color is light or dark based on luminance.
     *
     * @param color The color to check.
     *
     * @return True if light, false if dark.
     */
    fun isColorLight(@ColorInt color: Int): Boolean =
        ColorUtils.calculateLuminance(color) > 0.5

    /**
     * Parses CSS rgb/rgba string to color int. Supports formats: rgb(255, 255, 255), rgba(255, 255, 255, 1.0).
     *
     * @param rgb The CSS color string.
     *
     * @return The parsed color or null if invalid.
     */
    @ColorInt
    fun parseRgbColor(rgb: String): Int? {
        return runCatching {
            val numbers = rgb
                .substringAfter("(")
                .substringBefore(")")
                .split(",")
                .map { it.trim() }

            if (numbers.size < 3) return null

            val r = numbers[0].toInt().coerceIn(0, 255)
            val g = numbers[1].toInt().coerceIn(0, 255)
            val b = numbers[2].toInt().coerceIn(0, 255)

            if (numbers.size > 3) {
                val alpha = numbers[3].toFloat()
                if (alpha < 0.5f) return null
            }

            Color.rgb(r, g, b)
        }.getOrNull()
    }

    /**
     * Comprehensive color profile with multiple palette options.
     */
    data class ColorProfile(
        val dominant: Int?,
        val vibrant: Int?,
        val muted: Int?,
        val lightVibrant: Int?,
        val darkVibrant: Int?,
        val lightMuted: Int?,
        val darkMuted: Int?
    ) {
        constructor(palette: Palette?) : this(
            dominant = palette?.dominantSwatch?.rgb,
            vibrant = palette?.vibrantSwatch?.rgb,
            muted = palette?.mutedSwatch?.rgb,
            lightVibrant = palette?.lightVibrantSwatch?.rgb,
            darkVibrant = palette?.darkVibrantSwatch?.rgb,
            lightMuted = palette?.lightMutedSwatch?.rgb,
            darkMuted = palette?.darkMutedSwatch?.rgb
        )

        /**
         * Get the best available color with fallback.
         *
         * @param fallback The fallback color if no colors available.
         *
         * @return The best color or fallback.
         */
        @ColorInt
        fun getBestColor(@ColorInt fallback: Int): Int =
            vibrant ?: dominant ?: darkVibrant ?: muted ?: fallback
    }
}