package com.xsolla.android.mobile.offerwall.webview

import android.content.Context
import android.util.AttributeSet
import android.view.LayoutInflater
import android.widget.FrameLayout
import android.widget.ImageView
import androidx.annotation.ColorInt
import androidx.annotation.DrawableRes
import androidx.core.view.isVisible
import com.xsolla.android.mobile.offerwall.R

/**
 * Splash screen overlay for WebView.
 */
internal class WebViewSplashOverlay @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyleAttr: Int = 0
) : FrameLayout(context, attrs, defStyleAttr) {
    private val image: ImageView
    private val imageBackground: FrameLayout

    init {
        LayoutInflater.from(context).inflate(
            R.layout.xsolla_offerwall_loading_overlay, this, true
        )

        image = findViewById(R.id.xsolla_offerwall_loading_overlay_image)
        imageBackground = findViewById(R.id.xsolla_offerwall_loading_overlay_background)

        isVisible = false
    }

    /**
     * Show splash screen.
     *
     * @param drawable The drawable resource to display, null for no image.
     * @param backgroundColor The background color.
     */
    fun show(
        @DrawableRes drawable: Int?,
        @ColorInt backgroundColor: Int,
    ) {
        drawable?.let {
            image.setImageResource(it)
            image.isVisible = true
        } ?: run {
            image.isVisible = false
        }

        imageBackground.setBackgroundColor(backgroundColor)

        alpha = 0f
        isVisible = true

        animate()
            .alpha(1f)
            .setDuration(150)
            .setListener(null)
            .start()
    }

    /**
     * Hide immediately without animation.
     */
    fun hideImmediate() {
        isVisible = false
        alpha = 0f
    }
}
