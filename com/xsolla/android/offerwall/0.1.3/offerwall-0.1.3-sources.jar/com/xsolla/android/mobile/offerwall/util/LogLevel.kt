package com.xsolla.android.mobile.offerwall.util

enum class LogLevel {
    VERBOSE,
    DEBUG,
    INFO,
    WARN,
    ERROR
}
