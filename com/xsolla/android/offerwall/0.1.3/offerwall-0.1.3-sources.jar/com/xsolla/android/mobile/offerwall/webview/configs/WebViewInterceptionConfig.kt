package com.xsolla.android.mobile.offerwall.webview.configs

/**
 * URL interception configuration. Not parcelable due to functional interface.
 */
internal data class WebViewInterceptionConfig(
    val urlInterceptor: WebViewUrlInterceptor? = null,
    val interceptExternalLinks: Boolean = false,
    val interceptTelLinks: Boolean = true,
    val interceptMailtoLinks: Boolean = true
)
