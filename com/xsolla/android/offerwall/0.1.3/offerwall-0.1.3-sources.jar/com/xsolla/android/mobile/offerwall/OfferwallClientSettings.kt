package com.xsolla.android.mobile.offerwall

import android.graphics.Color
import androidx.annotation.ColorInt
import androidx.annotation.DrawableRes
import com.xsolla.android.mobile.offerwall.util.LogLevel

class OfferwallClientSettings private constructor(
    val placementId: String,
    val userId: String,
    val activity: Activity?,
    val openExternalLinksInBrowser: Boolean,
    val theme: Theme,
    val splash: Splash?,
    val useOpenAnimation: Boolean,
    val orientation: Orientation,
    val privacyPolicy: PrivacyPolicy?,
    val logLevel: LogLevel?
) {
    class Builder() {
        private var placementId: String? = null
        private var userId: String? = null
        private var activity: Activity? = null
        private var openExternalLinksInBrowser: Boolean = true
        private var theme: Theme = Theme.System
        private var splash: Splash? = null
        private var useOpenAnimation: Boolean = true
        private var orientation: Orientation = Orientation.Portrait
        private var privacyPolicy: PrivacyPolicy? = null
        private var logLevel: LogLevel? = null

        fun withPlacementId(placementId: String?): Builder = apply {
            this.placementId = placementId
        }

        fun withUserId(userId: String?): Builder = apply {
            this.userId = userId
        }

        fun withActivity(activity: Activity?): Builder = apply {
            this.activity = activity
        }

        fun withOpenExternalLinksInBrowser(openExternalLinksInBrowser: Boolean) = apply {
            this.openExternalLinksInBrowser = openExternalLinksInBrowser
        }

        fun withTheme(theme: Theme) = apply {
            this.theme = theme
        }

        fun withSplash(splash: Splash?) = apply {
            this.splash = splash
        }

        /** Sets whether the activity that contains the offerwall shows with animation (e.g. slides in, etc). */
        fun withUseOpenAnimation(useOpenAnimation: Boolean) = apply {
            this.useOpenAnimation = useOpenAnimation
        }

        /** Sets the screen orientation for the offerwall. Defaults to [Orientation.Portrait]. */
        fun withOrientation(orientation: Orientation) = apply {
            this.orientation = orientation
        }

        /** Sets privacy policy parameters for ad compliance (GDPR, COPPA, CCPA). */
        fun withPrivacyPolicy(privacyPolicy: PrivacyPolicy?) = apply {
            this.privacyPolicy = privacyPolicy
        }

        /**
         * Sets log level.
         *
         * @param logLevel A level to limit logging to or `null` for defaults.
         */
        fun withLogLevel(logLevel: LogLevel?) = apply {
            this.logLevel = logLevel
        }

        fun build(): OfferwallClientSettings {
            requireNotNull(placementId) { "Placement ID is required" }
            requireNotNull(userId) { "User ID is required" }

            return OfferwallClientSettings(
                placementId!!,
                userId!!,
                activity,
                openExternalLinksInBrowser,
                theme,
                splash,
                useOpenAnimation,
                orientation,
                privacyPolicy,
                logLevel
            )
        }
    }

    enum class Activity {
        Embedded
    }

    enum class Orientation {
        /** Lock to portrait. This is the default. */
        Portrait,
        /** Lock to landscape. */
        Landscape,
        /** Follow the device's current orientation. */
        Unspecified
    }

    /**
     * Privacy and consent settings for ad compliance.
     *
     * @param subjectToGDPR Whether GDPR applies to the user (`null` = server determines).
     * @param userConsent User consent value: `"0"` (no consent), `"1"` (consent given),
     *   or an IAB Transparency and Consent Framework string.
     * @param belowConsentAge Whether the user is under 13 (COPPA) or below local consent age (GDPR).
     * @param usPrivacy IAB US Privacy String (e.g. `"1YNN"`).
     */
    class PrivacyPolicy(
        val subjectToGDPR: Boolean? = null,
        val userConsent: String? = null,
        val belowConsentAge: Boolean? = null,
        val usPrivacy: String? = null
    )

    sealed class Theme {
        /** Manual theme colors (no auto-detection). */
        data class Custom(val colors: ThemeColors) : Theme()

        /** No theme customization (use system defaults). */
        data object System : Theme()
    }

    data class ThemeColors(
        @ColorInt val statusBarColor: Int,
        @ColorInt val navigationBarColor: Int
    ) {
        companion object {
            val DEFAULT_LIGHT = uniform(Color.WHITE)
            val DEFAULT_DARK = uniform(Color.BLACK)

            fun uniform(@ColorInt color: Int) =
                ThemeColors(color, color)
        }
    }

    class Splash(
        val type: SplashType = SplashType.Parallel,
        @DrawableRes val drawable: Int? = null,
        @ColorInt val backgroundColor: Int = Color.BLACK,
        val durationMillis: Long = 500L,
        val transition: SplashTransition = SplashTransition.Animated()
    )

    enum class SplashType {
        /** The offerwall starts loading only when the splash is hidden. */
        Synchronous,
        /** The offerwall starts loading immediately when the splash is shown. */
        Parallel
    }

    sealed class SplashTransition {
        /** The splash is hidden immediately without any animation. */
        data object Immediate : SplashTransition()

        /** The splash is hidden using a cross-fade animation. */
        data class Animated(
            val durationMillis: Long = 300L
        ) : SplashTransition() {
            init {
                require(durationMillis > 0) { "Fade duration must be positive." }
            }
        }
    }
}