package com.xsolla.offerwallsdk

import android.app.Activity
import android.content.pm.ActivityInfo
import com.xsolla.offerwallsdk.webview.WebViewActivity
import com.xsolla.offerwallsdk.webview.WebViewManager
import com.xsolla.offerwallsdk.webview.configs.WebViewBehaviorConfig
import com.xsolla.offerwallsdk.webview.configs.WebViewConfig
import com.xsolla.offerwallsdk.webview.configs.WebViewContentConfig
import com.xsolla.offerwallsdk.webview.configs.WebViewInterceptionConfig
import com.xsolla.offerwallsdk.webview.configs.WebViewLifecycleConfig
import com.xsolla.offerwallsdk.webview.configs.WebViewSplashConfig
import com.xsolla.offerwallsdk.webview.configs.WebViewSplashTransitionConfig
import com.xsolla.offerwallsdk.webview.configs.WebViewThemeColors
import com.xsolla.offerwallsdk.webview.configs.WebViewThemeConfig

internal object OfferwallWebViewEmbedded : IOfferwallWebView {
    override fun open(
        activity: Activity,
        url: String,
        settings: XOSettings,
        callback: IOfferwallWebViewCallback,
    ) {
        WebViewActivity.Companion.start(
            context = activity,
            config =
                WebViewConfig(
                    content =
                        WebViewContentConfig.Url(
                            url,
                        ),
                    splash =
                        settings.splash?.let {
                            when (it.type) {
                                XOSettings.SplashType.Synchronous ->
                                    WebViewSplashConfig.Synchronous(
                                        drawable = it.drawable,
                                        backgroundColor = it.backgroundColor,
                                        durationMillis = it.durationMillis,
                                        transition =
                                            when (val transition = it.transition) {
                                                XOSettings.SplashTransition.Immediate ->
                                                    WebViewSplashTransitionConfig.Immediate

                                                is XOSettings.SplashTransition.Animated ->
                                                    WebViewSplashTransitionConfig.Animated(
                                                        fadeInDuration = transition.durationMillis,
                                                    )
                                            },
                                    )

                                XOSettings.SplashType.Parallel ->
                                    WebViewSplashConfig.Parallel(
                                        drawable = it.drawable,
                                        backgroundColor = it.backgroundColor,
                                        minDurationMillis = it.durationMillis,
                                        transition =
                                            when (val transition = it.transition) {
                                                XOSettings.SplashTransition.Immediate ->
                                                    WebViewSplashTransitionConfig.Immediate

                                                is XOSettings.SplashTransition.Animated ->
                                                    WebViewSplashTransitionConfig.Animated(
                                                        fadeInDuration = transition.durationMillis,
                                                    )
                                            },
                                    )
                            }
                        },
                    theme =
                        when (val theme = settings.theme) {
                            XOSettings.Theme.System ->
                                WebViewThemeConfig.System

                            is XOSettings.Theme.Custom ->
                                WebViewThemeConfig.Manual(
                                    WebViewThemeColors(
                                        statusBarColor = theme.colors.statusBarColor,
                                        navigationBarColor = theme.colors.navigationBarColor,
                                    ),
                                )
                        },
                    lifecycle =
                        WebViewLifecycleConfig(
                            keepAlive = false,
                        ),
                    behavior =
                        WebViewBehaviorConfig(
                            allowBackNavigation = true,
                            showLoadingProgress = false,
                            enableJavaScript = true,
                            enableDomStorage = true,
                            allowFileAccess = false,
                        ),
                    activityTransition = settings.useOpenAnimation,
                    screenOrientation =
                        when (settings.orientation) {
                            XOSettings.Orientation.Portrait ->
                                ActivityInfo.SCREEN_ORIENTATION_PORTRAIT

                            XOSettings.Orientation.Landscape ->
                                ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE

                            XOSettings.Orientation.Unspecified ->
                                ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
                        },
                    interception =
                        WebViewInterceptionConfig(
                            interceptExternalLinks = settings.openExternalLinksInBrowser,
                            interceptMailtoLinks = settings.openExternalLinksInBrowser,
                            interceptTelLinks = settings.openExternalLinksInBrowser,
                        ),
                    openedCallback = { callback.onOpened() },
                    closedCallback = { callback.onClosed() },
                    errorCallback = { callback.onError(it) },
                ),
        )
    }

    override fun shutdown() {
        WebViewManager.invalidate()
    }
}
