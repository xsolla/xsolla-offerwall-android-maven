package com.xsolla.offerwallsdk.util

import android.annotation.SuppressLint
import android.content.Context
import android.provider.Settings

/**
 * Resolves device identifiers for ad attribution.
 *
 * - **Android ID** (IDFV equivalent): always available via [Settings.Secure.ANDROID_ID].
 * - **Google Advertising ID** (IDFA equivalent): resolved via reflection so that
 *   `play-services-ads-identifier` remains an optional dependency. Returns `null` when
 *   Play Services is absent, the user has opted out of ad tracking, or any error occurs.
 * - **App Set ID**: resolved via reflection so that `play-services-appset` remains an
 *   optional dependency. Returns `null` when Play Services is absent or any error occurs.
 *
 * Must be called on a **background thread** (the GAID and App Set ID lookups are IPC calls).
 */
internal data class DeviceIdentifiers(
    val androidId: String?,
    val advertisingId: String?,
    val appSetId: String?,
)

internal object DeviceIdProvider {
    @SuppressLint("HardwareIds")
    fun resolve(context: Context): DeviceIdentifiers {
        val androidId =
            try {
                Settings.Secure.getString(context.contentResolver, Settings.Secure.ANDROID_ID)
            } catch (e: Exception) {
                Logger.warn(e, "Failed to retrieve Android ID")
                null
            }

        val advertisingId = resolveAdvertisingId(context)
        val appSetId = resolveAppSetId(context)

        Logger.debug(
            "Resolved device identifiers: android_id=${androidId != null} advertising_id=${advertisingId != null} app_set_id=${appSetId != null}",
        )

        return DeviceIdentifiers(androidId, advertisingId, appSetId)
    }

    private fun resolveAdvertisingId(context: Context): String? {
        return try {
            val clientClass = Class.forName("com.google.android.gms.ads.identifier.AdvertisingIdClient")
            val getInfoMethod = clientClass.getMethod("getAdvertisingIdInfo", Context::class.java)
            val adInfo = getInfoMethod.invoke(null, context)

            val infoClass = adInfo.javaClass
            val isLimitedMethod = infoClass.getMethod("isLimitAdTrackingEnabled")
            val isLimited = isLimitedMethod.invoke(adInfo) as Boolean

            if (isLimited) {
                Logger.debug("User has opted out of ad tracking, skipping advertising ID")
                return null
            }

            val getIdMethod = infoClass.getMethod("getId")
            getIdMethod.invoke(adInfo) as? String
        } catch (e: ClassNotFoundException) {
            Logger.debug("Play Services ads-identifier not available, skipping advertising ID")
            null
        } catch (e: Exception) {
            Logger.warn(e, "Failed to retrieve Google Advertising ID")
            null
        }
    }

    /**
     * Resolves the App Set ID via reflection so that `play-services-appset` remains an
     * optional runtime dependency. Returns `null` when the library is absent or any
     * error occurs.
     *
     * Reflection call chain:
     *   AppSet.getClient(context) → AppSetIdClient.getAppSetIdInfo() → Task<AppSetIdInfo>
     *   Tasks.await(task) → AppSetIdInfo.getId() → String
     *
     * **Must be called from a background thread.** [Tasks.await] throws
     * [IllegalStateException] on the main thread, and the IPC completion is also
     * dispatched via the main [android.os.Looper] — so blocking the main thread while
     * waiting for the result would deadlock. See [OfferwallClient.open] for how the call
     * site ensures this runs off the main thread.
     */
    private fun resolveAppSetId(context: Context): String? =
        try {
            val appSetClass = Class.forName("com.google.android.gms.appset.AppSet")
            val getClientMethod = appSetClass.getMethod("getClient", Context::class.java)
            val client = getClientMethod.invoke(null, context)

            val getAppSetIdInfoMethod = client!!.javaClass.getMethod("getAppSetIdInfo")
            val task = getAppSetIdInfoMethod.invoke(client)

            val tasksClass = Class.forName("com.google.android.gms.tasks.Tasks")
            val taskClass = Class.forName("com.google.android.gms.tasks.Task")
            val awaitMethod = tasksClass.getMethod("await", taskClass)
            val info = awaitMethod.invoke(null, task)

            val getIdMethod = info!!.javaClass.getMethod("getId")
            getIdMethod.invoke(info) as? String
        } catch (e: ClassNotFoundException) {
            Logger.debug("Play Services appset not available, skipping App Set ID")
            null
        } catch (e: Exception) {
            Logger.warn(e, "Failed to retrieve App Set ID")
            null
        }
}
