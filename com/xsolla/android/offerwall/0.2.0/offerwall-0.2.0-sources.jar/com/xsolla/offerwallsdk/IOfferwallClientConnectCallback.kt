package com.xsolla.offerwallsdk

interface IOfferwallClientConnectCallback {
    fun onSuccess()

    fun onFailure(error: XOError)
}
