package com.xsolla.offerwallsdk.webview

import android.content.Context
import android.content.Intent
import android.content.res.Configuration
import android.os.Build
import android.os.Bundle
import android.util.Log
import android.util.TypedValue
import android.view.Gravity
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.ImageButton
import android.window.OnBackInvokedDispatcher
import androidx.core.content.ContextCompat
import androidx.core.net.toUri
import androidx.core.view.ViewCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.isVisible
import com.xsolla.offerwallsdk.R
import com.xsolla.offerwallsdk.XOError
import com.xsolla.offerwallsdk.webview.configs.WebViewConfig
import com.xsolla.offerwallsdk.webview.configs.WebViewContentConfig
import com.xsolla.offerwallsdk.webview.configs.WebViewInterceptionConfig
import com.xsolla.offerwallsdk.webview.configs.WebViewSplashConfig
import com.xsolla.offerwallsdk.webview.configs.WebViewSplashTransitionConfig
import com.xsolla.offerwallsdk.webview.configs.WebViewThemeColors
import com.xsolla.offerwallsdk.webview.configs.WebViewThemeConfig
import com.xsolla.offerwallsdk.webview.configs.WebViewUrlInterceptor

/**
 * Proxy activity for displaying WebView with splash screen and smooth transitions.
 */
internal class WebViewActivity : android.app.Activity() {
    private lateinit var container: FrameLayout
    private var webView: CustomWebView? = null
    private lateinit var splashOverlay: WebViewSplashOverlay
    private lateinit var config: WebViewConfig
    private var isWebViewReady = false
    private var systemUsesDarkTheme: Boolean = false
    private var splashShownAt: Long = 0
    private var notifiedAboutOpening: Boolean = false
    private var notifiedAboutClosing: Boolean = false
    private var createError: XOError? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        try {
            WindowCompat.setDecorFitsSystemWindows(window, false)

            systemUsesDarkTheme = isSystemDarkTheme()

            config = intent.getParcelableExtra(EXTRA_CONFIG) ?: run {
                Log.e(TAG, "No configuration provided")
                finish()
                return
            }

            if (!config.activityTransition) {
                overridePendingTransition(0, 0)
            }

            requestedOrientation = config.screenOrientation

            container =
                FrameLayout(this).apply {
                    layoutParams =
                        ViewGroup.LayoutParams(
                            ViewGroup.LayoutParams.MATCH_PARENT,
                            ViewGroup.LayoutParams.MATCH_PARENT,
                        )
                }

            WebViewManager
                .init(
                    context = this,
                ).apply {
                    layoutParams =
                        ViewGroup.LayoutParams(
                            ViewGroup.LayoutParams.MATCH_PARENT,
                            ViewGroup.LayoutParams.MATCH_PARENT,
                        )
                    isVisible = false
                }.also {
                    webView = it
                }

            webView!!.parent?.let { (it as ViewGroup).removeView(webView) }

            container.addView(webView)

            splashOverlay =
                WebViewSplashOverlay(this).apply {
                    layoutParams =
                        ViewGroup.LayoutParams(
                            ViewGroup.LayoutParams.MATCH_PARENT,
                            ViewGroup.LayoutParams.MATCH_PARENT,
                        )
                }

            splashOverlay.parent?.let { (it as ViewGroup).removeView(splashOverlay) }

            container.addView(splashOverlay)

            setContentView(container)

            setupSafeArea()
            setupCloseButton()

            setupWebView(webView!!)
            setupBackPress(webView!!)

            loadContent(webView!!)
        } catch (e: Exception) {
            createError = XOError("Failed to initialize the embedded webview", cause = e)
            finish()
        }
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)

        Log.d(TAG, "onConfigurationChanged")

        webView?.let {
            val oldSystemUsesDarkTheme = systemUsesDarkTheme
            systemUsesDarkTheme = isSystemDarkTheme()
            if (systemUsesDarkTheme != oldSystemUsesDarkTheme) {
                resetTheme(it)
            }
        }
    }

    override fun onStart() {
        super.onStart()

        if (!notifiedAboutOpening) {
            notifiedAboutOpening = true

            onOpenedCallback?.invoke()
        }
    }

    override fun onStop() {
        super.onStop()
    }

    override fun onResume() {
        super.onResume()

        Log.d(TAG, "onResume")

        if (!isFinishing) {
            webView?.onResume()
        }
    }

    override fun onPause() {
        super.onPause()

        Log.d(TAG, "onPause")

        if (!isFinishing) {
            webView?.onPause()
        }
    }

    override fun onDestroy() {
        Log.d(TAG, "onDestroy")

        if (!config.lifecycle.keepAlive) {
            WebViewManager.invalidate()
        }

        if (!notifiedAboutClosing) {
            notifiedAboutClosing = true

            if (createError != null) {
                onErrorCallback?.invoke(createError!!)
            } else {
                onClosedCallback?.invoke()
            }
        }

        super.onDestroy()
    }

    private fun setupWebView(webView: CustomWebView) {
        Log.d(TAG, "Setting up the webview")

        webView.apply {
            attachToWindow(window)

            resetTheme(webView)

            getWebView().settings.apply {
                javaScriptEnabled = config.behavior.enableJavaScript
                domStorageEnabled = config.behavior.enableDomStorage
                allowFileAccess = config.behavior.allowFileAccess
            }

            setupInterception(webView)
        }
    }

    private fun setupInterception(webView: CustomWebView) {
        if (interceptionConfig != null) {
            val compositeInterceptor =
                WebViewUrlInterceptor { url ->
                    if (interceptionConfig!!.urlInterceptor?.onUrlIntercept(url) == true) {
                        return@WebViewUrlInterceptor true
                    }

                    when {
                        interceptionConfig!!.interceptTelLinks && url.startsWith("tel:") -> {
                            Log.d(TAG, "Handling tel link: $url")
                            try {
                                val intent = Intent(Intent.ACTION_DIAL, url.toUri())
                                startActivity(intent)
                            } catch (e: Exception) {
                                Log.e(TAG, "Failed to handle tel link", e)
                            }
                            true
                        }

                        interceptionConfig!!.interceptMailtoLinks && url.startsWith("mailto:") -> {
                            Log.d(TAG, "Handling mailto link: $url")
                            try {
                                val intent = Intent(Intent.ACTION_SENDTO, url.toUri())
                                startActivity(intent)
                            } catch (e: Exception) {
                                Log.e(TAG, "Failed to handle mailto link", e)
                            }
                            true
                        }

                        interceptionConfig!!.interceptExternalLinks && isExternalLink(url) -> {
                            Log.d(TAG, "Handling external link: $url")
                            try {
                                val intent = Intent(Intent.ACTION_VIEW, url.toUri())
                                startActivity(intent)
                            } catch (e: Exception) {
                                Log.e(TAG, "Failed to handle external link", e)
                            }
                            true
                        }

                        else -> false
                    }
                }

            webView.setUrlInterceptor(compositeInterceptor)
        } else {
            webView.setUrlInterceptor(null)
        }
    }

    private fun setupSafeArea() {
        ViewCompat.setOnApplyWindowInsetsListener(container) { v, insets ->
            val bars =
                insets.getInsets(
                    WindowInsetsCompat.Type.systemBars() or WindowInsetsCompat.Type.displayCutout(),
                )
            v.setPadding(bars.left, bars.top, bars.right, bars.bottom)
            insets
        }
    }

    private fun setupCloseButton() {
        val touchTarget =
            TypedValue
                .applyDimension(
                    TypedValue.COMPLEX_UNIT_DIP,
                    48f,
                    resources.displayMetrics,
                ).toInt()
        val iconPadding =
            TypedValue
                .applyDimension(
                    TypedValue.COMPLEX_UNIT_DIP,
                    6f,
                    resources.displayMetrics,
                ).toInt()
        val endMargin =
            TypedValue
                .applyDimension(
                    TypedValue.COMPLEX_UNIT_DIP,
                    8f,
                    resources.displayMetrics,
                ).toInt()
        val defaultTopMargin =
            TypedValue
                .applyDimension(
                    TypedValue.COMPLEX_UNIT_DIP,
                    4f,
                    resources.displayMetrics,
                ).toInt()

        val closeButton =
            ImageButton(this).apply {
                setImageDrawable(ContextCompat.getDrawable(context, R.drawable.xsolla_offerwall_ic_close))
                background = null
                contentDescription = "Close"
                scaleType = android.widget.ImageView.ScaleType.FIT_CENTER
                setPadding(iconPadding, iconPadding, iconPadding, iconPadding)
                setOnClickListener { closeWebView() }
            }

        val lp =
            FrameLayout.LayoutParams(touchTarget, touchTarget).apply {
                gravity = Gravity.TOP or Gravity.END
                setMargins(0, defaultTopMargin, endMargin, 0)
            }

        window.addContentView(closeButton, lp)

        ViewCompat.setOnApplyWindowInsetsListener(closeButton) { v, insets ->
            val bars =
                insets.getInsets(
                    WindowInsetsCompat.Type.systemBars() or WindowInsetsCompat.Type.displayCutout(),
                )
            val params = v.layoutParams as FrameLayout.LayoutParams
            params.topMargin = bars.top + defaultTopMargin
            params.rightMargin = bars.right + endMargin
            v.layoutParams = params
            insets
        }
        closeButton.requestApplyInsets()
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        handleBackPress()
    }

    private fun setupBackPress(webView: CustomWebView) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            onBackInvokedDispatcher.registerOnBackInvokedCallback(
                OnBackInvokedDispatcher.PRIORITY_DEFAULT,
            ) {
                handleBackPress()
            }
        }
    }

    private fun handleBackPress() {
        val innerWebView =
            webView?.getWebView() ?: run {
                closeWebView()
                return
            }
        when {
            config.behavior.allowBackNavigation && innerWebView.canGoBack() -> {
                innerWebView.goBack()
            }
            else -> {
                closeWebView()
            }
        }
    }

    private fun loadContent(webView: CustomWebView) {
        fun handlePageRendered(webView: CustomWebView) {
            if (isWebViewReady) return

            Log.d(TAG, "Page fully rendered")

            isWebViewReady = true

            when (val splash = config.splash) {
                null -> showWebView(webView)
                is WebViewSplashConfig.Synchronous -> showWebView(webView)
                is WebViewSplashConfig.Parallel -> {
                    val elapsedTime = System.currentTimeMillis() - splashShownAt
                    val remainingTime = splash.minDurationMillis - elapsedTime
                    if (remainingTime > 0) {
                        webView.postDelayed({
                            showWebView(webView)
                        }, remainingTime)
                    } else {
                        showWebView(webView)
                    }
                }
            }
        }

        fun loadWebViewContent() {
            when (val content = config.content) {
                is WebViewContentConfig.Url -> {
                    WebViewManager.loadUrl(
                        context = this,
                        config =
                            WebViewManager.LoadConfig(
                                content.url,
                                content.headers,
                            ),
                        force = false,
                    ) {
                        handlePageRendered(it)
                    }
                }
            }
        }

        when (val splash = config.splash) {
            null -> {
                splashOverlay.hideImmediate()
                loadWebViewContent()
            }
            is WebViewSplashConfig.Synchronous -> {
                splashShownAt = System.currentTimeMillis()
                splashOverlay.show(
                    drawable = splash.drawable,
                    backgroundColor = splash.backgroundColor,
                )
                webView.postDelayed({
                    loadWebViewContent()
                }, splash.durationMillis)
            }
            is WebViewSplashConfig.Parallel -> {
                splashShownAt = System.currentTimeMillis()
                splashOverlay.show(
                    drawable = splash.drawable,
                    backgroundColor = splash.backgroundColor,
                )
                loadWebViewContent()
            }
        }
    }

    private fun resetTheme(webView: CustomWebView) {
        when (val theme = config.theme) {
            is WebViewThemeConfig.Manual -> {
                webView.setThemeColors(theme.colors)
            }
            WebViewThemeConfig.System -> {
                webView.setThemeColors(
                    if (systemUsesDarkTheme) {
                        WebViewThemeColors.DEFAULT_DARK
                    } else {
                        WebViewThemeColors.DEFAULT_LIGHT
                    },
                )
            }
        }
    }

    private fun isExternalLink(url: String): Boolean {
        val initialUrl =
            when (val content = config.content) {
                is WebViewContentConfig.Url -> content.url
            }
        return try {
            val currentDomain = url.toUri().host
            val initialDomain = initialUrl.toUri().host
            currentDomain != initialDomain
        } catch (_: Exception) {
            false
        }
    }

    private fun showWebView(webView: CustomWebView) {
        Log.d(TAG, "showWebView")

        val transition = config.splash?.transition ?: WebViewSplashTransitionConfig.Immediate

        when (transition) {
            WebViewSplashTransitionConfig.Immediate -> {
                splashOverlay.hideImmediate()
                WebViewTransition.showImmediate(webView)
            }
            is WebViewSplashTransitionConfig.Animated -> {
                WebViewTransition.crossFade(
                    fromView = splashOverlay,
                    toView = webView,
                    duration = transition.fadeInDuration,
                )
            }
        }
    }

    private fun closeWebView() {
        Log.d(TAG, "closeWebView")

        finish()

        if (!config.activityTransition) {
            overridePendingTransition(0, 0)
        }
    }

    private fun isSystemDarkTheme(): Boolean =
        (resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK) == Configuration.UI_MODE_NIGHT_YES

    companion object {
        private const val TAG = "WebViewActivity"
        private const val EXTRA_CONFIG = "extra_config"

        private var interceptionConfig: WebViewInterceptionConfig? = null

        private var onOpenedCallback: (() -> Unit)? = null
        private var onClosedCallback: (() -> Unit)? = null
        private var onErrorCallback: ((XOError) -> Unit)? = null

        /**
         * Start WebView activity with configuration.
         *
         * @param context The context.
         * @param config The WebView configuration.
         */
        fun start(
            context: Context,
            config: WebViewConfig,
        ) {
            interceptionConfig = config.interception

            onOpenedCallback = config.openedCallback
            onClosedCallback = config.closedCallback
            onErrorCallback = config.errorCallback

            val intent =
                Intent(context, WebViewActivity::class.java).apply {
                    putExtra(EXTRA_CONFIG, config)
                }

            context.startActivity(intent)
        }

        fun warmUp(
            context: Context,
            url: String,
            headers: Map<String, String> = emptyMap(),
        ) {
            Log.d(TAG, "Warming up WebView: $url")

            WebViewManager.loadUrl(context, WebViewManager.LoadConfig(url, headers))
        }
    }
}
