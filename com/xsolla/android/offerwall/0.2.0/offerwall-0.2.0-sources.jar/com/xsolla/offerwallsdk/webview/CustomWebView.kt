package com.xsolla.offerwallsdk.webview

import android.annotation.SuppressLint
import android.content.Context
import android.graphics.Bitmap
import android.os.Build
import android.util.AttributeSet
import android.util.Log
import android.view.LayoutInflater
import android.view.Window
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.ProgressBar
import androidx.annotation.ColorInt
import androidx.core.view.isVisible
import com.xsolla.offerwallsdk.R
import com.xsolla.offerwallsdk.webview.configs.WebViewThemeColors
import com.xsolla.offerwallsdk.webview.configs.WebViewUrlInterceptor
import com.xsolla.offerwallsdk.webview.util.ColorUtil

/**
 * Flexible WebView wrapper with URL interception and dynamic theming.
 */
@Suppress("DEPRECATION")
internal class CustomWebView
    @JvmOverloads
    constructor(
        context: Context,
        attrs: AttributeSet? = null,
        defStyleAttr: Int = 0,
    ) : android.widget.FrameLayout(context, attrs, defStyleAttr) {
        private val webView: WebView
        private val progressBar: ProgressBar

        private var window: Window? = null
        private var urlInterceptor: WebViewUrlInterceptor? = null

        private var isPageFullyRendered = false
        private var onPageRenderedCallback: (() -> Unit)? = null

        private var currentUrl: String? = null

        init {
            LayoutInflater.from(context).inflate(
                R.layout.xsolla_offerwall_flexible_webview,
                this,
                true,
            )

            webView = findViewById(R.id.xsolla_offerwall_webview)
            progressBar = findViewById(R.id.xsolla_offerwall_webview_progress_bar)

            setupWebView()
        }

        /**
         * Set URL interceptor callback.
         *
         * @param interceptor Callback that returns true if URL was handled.
         */
        fun setUrlInterceptor(interceptor: WebViewUrlInterceptor?) {
            this.urlInterceptor = interceptor
        }

        /**
         * Attach to activity window for theme management. Must be called before loading any URL.
         *
         * @param window The activity window.
         */
        fun attachToWindow(window: Window) {
            this.window = window
        }

        /**
         * Manually set theme colors.
         *
         * @param colors The theme colors.
         */
        fun setThemeColors(colors: WebViewThemeColors) {
            applyStatusBarColor(colors.statusBarColor)
            applyNavigationBarColor(colors.navigationBarColor)
        }

        /**
         * Set callback for when page is fully rendered and ready to display.
         *
         * @param callback The callback to invoke when page is rendered.
         */
        fun setOnPageRenderedCallback(callback: (() -> Unit)?) {
            onPageRenderedCallback = callback
        }

        fun loadUrl(
            url: String,
            headers: Map<String, String> = emptyMap(),
        ) {
            Log.d(TAG, "Loading URL: $url")

            currentUrl = url

            if (!headers.isEmpty()) {
                webView.loadUrl(url, headers)
            } else {
                webView.loadUrl(url)
            }
        }

        fun getUrl(): String? = currentUrl

        fun clear() {
            webView.clearCache(true)
            currentUrl = null
        }

        /**
         * Returns the underlying WebView instance for advanced usage.
         *
         * @return The WebView instance.
         */
        fun getWebView(): WebView = webView

        /**
         * Resumes WebView.
         */
        fun onResume() {
            webView.onResume()
        }

        /**
         * Pauses WebView.
         */
        fun onPause() {
            webView.onPause()
        }

        /**
         * Destroys WebView and cleans up resources.
         */
        fun destroy() {
            Log.d(TAG, "Destroying")
            webView.destroy()
        }

        @SuppressLint("SetJavaScriptEnabled")
        private fun setupWebView() {
            webView.apply {
                settings.apply {
                    javaScriptEnabled = true
                    domStorageEnabled = true
                    databaseEnabled = true
                    loadWithOverviewMode = true
                    useWideViewPort = true
                    builtInZoomControls = false
                    displayZoomControls = false

                    allowFileAccess = false
                    allowContentAccess = false

                    allowFileAccessFromFileURLs = false
                    allowUniversalAccessFromFileURLs = false
                }

                webViewClient = FlexibleWebViewClient()
                webChromeClient = FlexibleWebChromeClient()
            }
        }

        /**
         * Applies status bar color and adjusts icon colors.
         */
        private fun applyStatusBarColor(
            @ColorInt color: Int,
        ) {
            val window = this.window ?: return

            window.statusBarColor = color

            val decorView = window.decorView
            val isLight = ColorUtil.isColorLight(color)

            decorView.systemUiVisibility =
                if (isLight) {
                    decorView.systemUiVisibility or SYSTEM_UI_FLAG_LIGHT_STATUS_BAR
                } else {
                    decorView.systemUiVisibility and SYSTEM_UI_FLAG_LIGHT_STATUS_BAR.inv()
                }
        }

        /**
         * Applies navigation bar color and adjusts icon colors.
         */
        private fun applyNavigationBarColor(
            @ColorInt color: Int,
        ) {
            val window = this.window ?: return

            window.navigationBarColor = color

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                val decorView = window.decorView
                val isLight = ColorUtil.isColorLight(color)

                decorView.systemUiVisibility =
                    if (isLight) {
                        decorView.systemUiVisibility or SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR
                    } else {
                        decorView.systemUiVisibility and SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR.inv()
                    }
            }
        }

        /**
         * Marks page as rendered and invokes callback (once).
         */
        private fun markPageAsRendered() {
            if (!isPageFullyRendered) {
                isPageFullyRendered = true
                onPageRenderedCallback?.invoke()
            }
        }

        private inner class FlexibleWebViewClient : WebViewClient() {
            private var hasError = false

            override fun shouldOverrideUrlLoading(
                view: WebView?,
                request: WebResourceRequest?,
            ): Boolean {
                val url = request?.url?.toString() ?: return false

                // Reset rendering state on new navigation.
                isPageFullyRendered = false

                // Check if interceptor handles the URL.
                return urlInterceptor?.onUrlIntercept(url) ?: false
            }

            @Deprecated("Deprecated in Java")
            override fun shouldOverrideUrlLoading(
                view: WebView?,
                url: String?,
            ): Boolean {
                if (url != null) {
                    isPageFullyRendered = false
                }
                if (url == null) return false
                return urlInterceptor?.onUrlIntercept(url) ?: false
            }

            override fun onPageStarted(
                view: WebView?,
                url: String?,
                favicon: Bitmap?,
            ) {
                super.onPageStarted(view, url, favicon)
                hasError = false
                isPageFullyRendered = false
                progressBar.isVisible = true
            }

            override fun onPageFinished(
                view: WebView?,
                url: String?,
            ) {
                super.onPageFinished(view, url)
                progressBar.isVisible = false

                if (!hasError) {
                    // Wait a bit for rendering to complete.
                    postDelayed({
                        if (!hasError) {
                            markPageAsRendered()
                        }
                    }, 100)
                }
            }

            override fun onPageCommitVisible(
                view: WebView?,
                url: String?,
            ) {
                super.onPageCommitVisible(view, url)
                // Page is becoming visible to user.
                if (!hasError) {
                    markPageAsRendered()
                }
            }

            @Deprecated("Deprecated in Java")
            override fun onReceivedError(
                view: WebView?,
                errorCode: Int,
                description: String?,
                failingUrl: String?,
            ) {
                super.onReceivedError(view, errorCode, description, failingUrl)
                hasError = true
                progressBar.isVisible = false
                // Still notify as "rendered" even on error.
                markPageAsRendered()
            }

            override fun onReceivedHttpError(
                view: WebView?,
                request: WebResourceRequest?,
                errorResponse: WebResourceResponse?,
            ) {
                super.onReceivedHttpError(view, request, errorResponse)
                if (request?.isForMainFrame == true) {
                    hasError = true
                }
            }
        }

        private inner class FlexibleWebChromeClient : WebChromeClient() {
            override fun onProgressChanged(
                view: WebView?,
                newProgress: Int,
            ) {
                super.onProgressChanged(view, newProgress)
                progressBar.progress = newProgress
            }
        }

        companion object {
            private const val TAG = "FlexibleWebView"
        }
    }
