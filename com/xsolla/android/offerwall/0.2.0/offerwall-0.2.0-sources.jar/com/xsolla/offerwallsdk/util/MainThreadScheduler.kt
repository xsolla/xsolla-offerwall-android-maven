package com.xsolla.offerwallsdk.util

import android.os.Looper
import androidx.annotation.AnyThread
import androidx.core.os.HandlerCompat

object MainThreadScheduler {
    private val handler by lazy {
        HandlerCompat.createAsync(Looper.getMainLooper())
    }

    @AnyThread
    fun schedule(action: (() -> Unit)) {
        handler.post(action)
    }
}
