package com.xsolla.offerwallsdk.webview.configs

import android.os.Parcelable
import com.xsolla.offerwallsdk.XOError
import kotlinx.parcelize.IgnoredOnParcel
import kotlinx.parcelize.Parcelize

/**
 * Main configuration for WebView with grouped, type-safe parameters.
 */
@Parcelize
internal data class WebViewConfig(
    val content: WebViewContentConfig,
    val splash: WebViewSplashConfig? = null,
    val theme: WebViewThemeConfig = WebViewThemeConfig.System,
    val lifecycle: WebViewLifecycleConfig = WebViewLifecycleConfig(),
    val behavior: WebViewBehaviorConfig = WebViewBehaviorConfig(),
    val activityTransition: Boolean = true,
    val screenOrientation: Int = android.content.pm.ActivityInfo.SCREEN_ORIENTATION_PORTRAIT,
    @IgnoredOnParcel
    val interception: WebViewInterceptionConfig = WebViewInterceptionConfig(),
    @IgnoredOnParcel
    val openedCallback: (() -> Unit)? = null,
    @IgnoredOnParcel
    val closedCallback: (() -> Unit)? = null,
    @IgnoredOnParcel
    val errorCallback: ((XOError) -> Unit)? = null,
) : Parcelable
