package com.xsolla.offerwallsdk.webview.configs

/**
 * Interface for intercepting URL navigation in WebView
 */
internal fun interface WebViewUrlInterceptor {
    /**
     * Called when a URL is about to be loaded
     *
     * @param url The URL to be loaded
     *
     * @return true if the URL was handled (WebView won't load it), false otherwise
     */
    fun onUrlIntercept(url: String): Boolean
}
