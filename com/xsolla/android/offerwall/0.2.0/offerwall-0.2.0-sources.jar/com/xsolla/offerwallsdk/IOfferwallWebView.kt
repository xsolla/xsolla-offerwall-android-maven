package com.xsolla.offerwallsdk

import android.app.Activity

internal interface IOfferwallWebView {
    fun open(
        activity: Activity,
        url: String,
        settings: XOSettings,
        callback: IOfferwallWebViewCallback,
    )

    fun shutdown()
}
