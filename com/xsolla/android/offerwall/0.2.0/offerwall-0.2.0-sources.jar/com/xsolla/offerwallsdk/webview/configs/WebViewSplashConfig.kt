package com.xsolla.offerwallsdk.webview.configs

import android.graphics.Color
import android.os.Parcelable
import androidx.annotation.ColorInt
import androidx.annotation.DrawableRes
import kotlinx.parcelize.Parcelize

/**
 * Splash screen configuration.
 */
@Parcelize
internal sealed class WebViewSplashConfig : Parcelable {
    abstract val drawable: Int?
    abstract val backgroundColor: Int
    abstract val transition: WebViewSplashTransitionConfig

    @Parcelize
    data class Synchronous(
        @DrawableRes override val drawable: Int? = null,
        @ColorInt override val backgroundColor: Int = Color.BLACK,
        val durationMillis: Long = 500L,
        override val transition: WebViewSplashTransitionConfig = WebViewSplashTransitionConfig.Animated(),
    ) : WebViewSplashConfig() {
        init {
            require(durationMillis >= 0) { "Duration must be non-negative." }
        }
    }

    @Parcelize
    data class Parallel(
        @DrawableRes override val drawable: Int? = null,
        @ColorInt override val backgroundColor: Int = Color.BLACK,
        val minDurationMillis: Long = 500L,
        override val transition: WebViewSplashTransitionConfig = WebViewSplashTransitionConfig.Animated(),
    ) : WebViewSplashConfig() {
        init {
            require(minDurationMillis >= 0) { "Min duration must be non-negative." }
        }
    }
}
