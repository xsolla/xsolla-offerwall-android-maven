package com.xsolla.offerwallsdk.webview.configs

import android.os.Parcelable
import kotlinx.parcelize.Parcelize

/**
 * WebView lifecycle and memory management.
 */
@Parcelize
internal data class WebViewLifecycleConfig(
    val keepAlive: Boolean = false,
) : Parcelable
