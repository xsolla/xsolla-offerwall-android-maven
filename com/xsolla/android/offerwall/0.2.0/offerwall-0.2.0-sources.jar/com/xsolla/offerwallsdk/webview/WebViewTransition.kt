package com.xsolla.offerwallsdk.webview

import android.animation.Animator
import android.animation.AnimatorListenerAdapter
import android.animation.ValueAnimator
import android.view.View
import androidx.core.view.isVisible

/**
 * Handles smooth transitions for WebView visibility.
 */
internal object WebViewTransition {
    fun crossFade(
        fromView: View,
        toView: View,
        duration: Long,
        onComplete: () -> Unit = {},
    ) {
        toView.alpha = 0f
        toView.isVisible = true

        ValueAnimator.ofFloat(0f, 1f).apply {
            this.duration = duration
            addUpdateListener { animator ->
                val progress = animator.animatedValue as Float
                toView.alpha = progress
                fromView.alpha = 1f - progress
            }
            addListener(
                object : android.animation.AnimatorListenerAdapter() {
                    override fun onAnimationEnd(animation: Animator) {
                        fromView.isVisible = false
                        onComplete()
                    }
                },
            )
            start()
        }
    }

    /**
     * Show WebView immediately.
     *
     * @param view The view to show.
     */
    fun showImmediate(view: View) {
        view.alpha = 1f
        view.isVisible = true
    }

    /**
     * Hide WebView immediately.
     *
     * @param view The view to hide.
     */
    fun hideImmediate(view: View) {
        view.alpha = 0f
        view.isVisible = false
    }
}
