package com.xsolla.offerwallsdk

internal sealed class OfferwallClientState {
    data object Disconnected : OfferwallClientState()

    data object Connecting : OfferwallClientState()

    class Connected(
        val webView: IOfferwallWebView,
    ) : OfferwallClientState()

    data object Closed : OfferwallClientState()
}
