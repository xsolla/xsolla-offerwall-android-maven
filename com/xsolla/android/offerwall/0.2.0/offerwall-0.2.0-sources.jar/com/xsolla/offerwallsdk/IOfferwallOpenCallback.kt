package com.xsolla.offerwallsdk

interface IOfferwallOpenCallback {
    fun onOpened()

    fun onError(error: XOError)

    fun onClosed()
}
