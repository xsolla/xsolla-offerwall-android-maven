package com.xsolla.offerwallsdk.webview.configs

import android.graphics.Color
import android.os.Parcelable
import androidx.annotation.ColorInt
import kotlinx.parcelize.Parcelize

@Parcelize
internal data class WebViewThemeColors(
    @ColorInt val statusBarColor: Int,
    @ColorInt val navigationBarColor: Int,
) : Parcelable {
    companion object {
        val DEFAULT_LIGHT = uniform(Color.WHITE)
        val DEFAULT_DARK = uniform(Color.BLACK)

        fun uniform(
            @ColorInt color: Int,
        ) = WebViewThemeColors(color, color)
    }
}
