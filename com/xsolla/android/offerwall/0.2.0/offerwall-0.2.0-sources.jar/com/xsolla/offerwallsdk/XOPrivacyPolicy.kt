package com.xsolla.offerwallsdk

/**
 * Privacy and consent settings for ad compliance.
 *
 * @param subjectToGDPR Whether GDPR applies to the user (`null` = server determines).
 * @param userConsent User consent value: `"0"` (no consent), `"1"` (consent given),
 *   or an IAB Transparency and Consent Framework string.
 * @param belowConsentAge Whether the user is under 13 (COPPA) or below local consent age (GDPR).
 * @param usPrivacy IAB US Privacy String (e.g. `"1YNN"`).
 */
object XOPrivacyPolicy {
    var subjectToGDPR: Boolean? = null
    var userConsent: String? = null
    var belowConsentAge: Boolean? = null
    var usPrivacy: String? = null
}
