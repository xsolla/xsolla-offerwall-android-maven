package com.xsolla.offerwallsdk.webview

import android.content.Context
import android.os.Handler
import android.os.Looper
import android.util.Log

internal object WebViewManager {
    private const val TAG = "WebViewManager"

    data class LoadConfig(
        val url: String,
        val headers: Map<String, String>? = null,
    )

    private sealed interface State {
        data class Initialized(
            val webView: CustomWebView,
        ) : State
    }

    private var state: State? = null
    private val stateLock = Any()

    private val mainHandler = Handler(Looper.getMainLooper())

    private val callbacks: MutableList<(CustomWebView) -> Unit> = mutableListOf()
    private val callbacksLock = Any()

    fun init(context: Context): CustomWebView {
        synchronized(stateLock) {
            (state as? State.Initialized)?.let { return it.webView }

            val webView = CustomWebView(context)

            webView.setOnPageRenderedCallback {
                handlePageRendered(webView)
            }

            state = State.Initialized(webView)

            Log.d(TAG, "Initialized")

            return webView
        }
    }

    fun loadUrl(
        context: Context,
        config: LoadConfig,
        force: Boolean = false,
        callback: ((CustomWebView) -> Unit)? = null,
    ): CustomWebView {
        Log.d(TAG, "Loading URL: ${config.url} (headers=${config.headers})")

        val webView = init(context)

        if (callback != null) {
            synchronized(callbacksLock) {
                callbacks.add(callback)
            }
        }

        if (force || !(webView.getUrl()?.let { it.compareTo(config.url) == 0 } ?: false)) {
            mainHandler.post {
                if (config.headers != null && config.headers.isNotEmpty()) {
                    webView.loadUrl(config.url, config.headers)
                } else {
                    webView.loadUrl(config.url)
                }
            }
        } else if (webView.getWebView().progress == 100) {
            Log.d(TAG, "URL is already loaded: ${config.url}")
            handlePageRendered(webView)
        }

        return webView
    }

    fun invalidate() {
        val webView: CustomWebView?

        synchronized(callbacksLock) {
            callbacks.clear()
        }

        synchronized(stateLock) {
            webView = (state as? State.Initialized)?.webView

            state = null
        }

        webView?.apply {
            clear()
            destroy()
        }

        Log.d(TAG, "Invalidated")
    }

    private fun handlePageRendered(webView: CustomWebView) {
        val pendingCallbacks: List<(CustomWebView) -> Unit>

        synchronized(callbacksLock) {
            pendingCallbacks = callbacks.toList()
            callbacks.clear()
        }

        if (!pendingCallbacks.isEmpty()) {
            mainHandler.post {
                pendingCallbacks.forEach { it.invoke(webView) }
            }
        }
    }
}
