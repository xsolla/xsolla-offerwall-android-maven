package com.xsolla.offerwallsdk

internal interface IOfferwallWebViewCallback {
    fun onOpened()

    fun onClosed()

    fun onError(error: XOError)
}
