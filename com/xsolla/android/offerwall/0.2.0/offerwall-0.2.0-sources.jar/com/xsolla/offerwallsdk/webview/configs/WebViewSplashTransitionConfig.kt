package com.xsolla.offerwallsdk.webview.configs

import android.os.Parcelable
import kotlinx.parcelize.Parcelize

/**
 * How the WebView appears after loading.
 */
@Parcelize
internal sealed class WebViewSplashTransitionConfig : Parcelable {
    /**
     * Show immediately without animation.
     */
    @Parcelize
    data object Immediate : WebViewSplashTransitionConfig()

    /**
     * Fade in animation.
     */
    @Parcelize
    data class Animated(
        val fadeInDuration: Long = 300L,
    ) : WebViewSplashTransitionConfig() {
        init {
            require(fadeInDuration > 0) { "Fade duration must be positive." }
        }
    }
}
