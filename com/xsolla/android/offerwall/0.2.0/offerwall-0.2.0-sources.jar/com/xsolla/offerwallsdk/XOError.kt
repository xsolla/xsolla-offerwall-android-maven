package com.xsolla.offerwallsdk

class XOError(
    val message: String,
    val cause: Throwable? = null,
)
