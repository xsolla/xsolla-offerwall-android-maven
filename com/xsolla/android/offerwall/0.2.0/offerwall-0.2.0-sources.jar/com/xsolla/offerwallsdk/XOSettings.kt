package com.xsolla.offerwallsdk

import android.graphics.Color
import androidx.annotation.ColorInt
import androidx.annotation.DrawableRes
import com.xsolla.offerwallsdk.util.LogLevel

class XOSettings {
    var openExternalLinksInBrowser: Boolean = true
    var theme: Theme = Theme.System
    var splash: Splash? = null
    var useOpenAnimation: Boolean = true
    var orientation: Orientation = Orientation.Portrait
    var logLevel: LogLevel? = null

    enum class Orientation {
        /** Lock to portrait. This is the default. */
        Portrait,

        /** Lock to landscape. */
        Landscape,

        /** Follow the device's current orientation. */
        Unspecified,
    }

    sealed class Theme {
        /** Manual theme colors (no auto-detection). */
        data class Custom(
            val colors: ThemeColors,
        ) : Theme()

        /** No theme customization (use system defaults). */
        data object System : Theme()
    }

    data class ThemeColors(
        @ColorInt val statusBarColor: Int,
        @ColorInt val navigationBarColor: Int,
    ) {
        companion object {
            val DEFAULT_LIGHT = uniform(Color.WHITE)
            val DEFAULT_DARK = uniform(Color.BLACK)

            fun uniform(
                @ColorInt color: Int,
            ) = ThemeColors(color, color)
        }
    }

    class Splash(
        val type: SplashType = SplashType.Parallel,
        @DrawableRes val drawable: Int? = null,
        @ColorInt val backgroundColor: Int = Color.BLACK,
        val durationMillis: Long = 500L,
        val transition: SplashTransition = SplashTransition.Animated(),
    )

    enum class SplashType {
        /** The offerwall starts loading only when the splash is hidden. */
        Synchronous,

        /** The offerwall starts loading immediately when the splash is shown. */
        Parallel,
    }

    sealed class SplashTransition {
        /** The splash is hidden immediately without any animation. */
        data object Immediate : SplashTransition()

        /** The splash is hidden using a cross-fade animation. */
        data class Animated(
            val durationMillis: Long = 300L,
        ) : SplashTransition() {
            init {
                require(durationMillis > 0) { "Fade duration must be positive." }
            }
        }
    }
}
