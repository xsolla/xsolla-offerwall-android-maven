package com.xsolla.offerwallsdk.util

import android.util.Log
import androidx.annotation.AnyThread
import com.xsolla.offerwallsdk.XOError
import kotlin.concurrent.Volatile

@AnyThread
internal object Logger {
    const val TAG: String = "XsollaOfferwallSDK"

    private val DEFAULT_LEVEL: LogLevel = LogLevel.ERROR

    private const val ALLOW_DEBUG_LEVEL: Boolean = true

    @Volatile
    private var level: LogLevel = LogLevel.ERROR

    /**
     * Sets log level.
     *
     * @param level Log level or `null` for default.
     */
    fun setLevel(level: LogLevel?) {
        this.level = level ?: DEFAULT_LEVEL
    }

    fun info(msg: String) {
        infoImpl(null, msg)
    }

    fun info(
        throwable: Throwable,
        msg: String,
    ) {
        infoImpl(throwable, msg)
    }

    fun warn(msg: String) {
        warnImpl(null, msg)
    }

    fun warn(
        throwable: Throwable,
        msg: String,
    ) {
        warnImpl(throwable, msg)
    }

    fun error(msg: String) {
        errorImpl(null, msg)
    }

    fun error(
        throwable: Throwable,
        msg: String,
    ) {
        errorImpl(throwable, msg)
    }

    fun error(err: XOError) {
        errorImpl(err.cause, err.message)
    }

    fun errorD(msg: String) {
        if (isAllowed(LogLevel.DEBUG)) {
            error(msg)
        }
    }

    fun errorD(
        throwable: Throwable,
        msg: String,
    ) {
        if (isAllowed(LogLevel.DEBUG)) {
            error(throwable, msg)
        }
    }

    fun debug(msg: String) {
        debugImpl(null, msg)
    }

    fun debug(
        throwable: Throwable,
        msg: String,
    ) {
        debugImpl(throwable, msg)
    }

    fun verbose(msg: String) {
        if (isAllowed(LogLevel.VERBOSE)) {
            Log.v(TAG, msg)
        }
    }

    /** Checks whether the specified [LogLevel] can be output. */
    fun isAllowed(level: LogLevel): Boolean {
        @Suppress("SimplifyBooleanWithConstants", "KotlinConstantConditions")
        return level >= this.level &&
            (
                level != LogLevel.DEBUG || ALLOW_DEBUG_LEVEL
            )
    }

    private fun infoImpl(
        throwable: Throwable?,
        msg: String,
    ) {
        if (isAllowed(LogLevel.INFO)) {
            if (throwable != null) {
                Log.i(TAG, msg, throwable)
            } else {
                Log.i(TAG, msg)
            }
        }
    }

    private fun warnImpl(
        throwable: Throwable?,
        msg: String,
    ) {
        if (isAllowed(LogLevel.WARN)) {
            if (throwable != null) {
                Log.w(TAG, msg, throwable)
            } else {
                Log.w(TAG, msg)
            }
        }
    }

    private fun errorImpl(
        throwable: Throwable?,
        msg: String,
    ) {
        if (isAllowed(LogLevel.ERROR)) {
            if (throwable != null) {
                Log.e(TAG, msg, throwable)
            } else {
                Log.e(TAG, msg)
            }
        }
    }

    private fun debugImpl(
        throwable: Throwable?,
        msg: String,
    ) {
        if (isAllowed(LogLevel.DEBUG)) {
            if (throwable != null) {
                Log.d(TAG, msg, throwable)
            } else {
                Log.d(TAG, msg)
            }
        }
    }

    private fun LogLevel.toLevel(): Int =
        when (this) {
            LogLevel.VERBOSE -> Log.VERBOSE
            LogLevel.DEBUG -> Log.DEBUG
            LogLevel.INFO -> Log.INFO
            LogLevel.WARN -> Log.WARN
            else -> Log.ERROR
        }
}
