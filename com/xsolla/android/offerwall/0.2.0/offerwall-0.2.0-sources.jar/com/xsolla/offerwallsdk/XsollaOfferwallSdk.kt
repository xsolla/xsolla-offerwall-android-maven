package com.xsolla.offerwallsdk

import android.app.Activity
import android.content.Context
import android.os.Build

object XsollaOfferwallSdk {
    private var client: OfferwallClient? = null
    private var userId: String = ""
    private val settings: XOSettings = XOSettings()

    fun getSettings(): XOSettings = settings

    fun getUserId(): String = userId

    fun setUserId(userId: String) {
        this.userId = userId
    }

    /**
     * Controls whether the Android Device ID (`Settings.Secure.ANDROID_ID`) is
     * included as the `device_id` query parameter in the offerwall URL.
     *
     * Defaults to `false`. The setting is persisted across app sessions and may be
     * called **before or after** [connect].
     *
     * @param context Any [Context]; the application context is used internally.
     * @param enabled `true` to include the Android Device ID; `false` to omit it.
     */
    fun setAndroidDeviceIdEnabled(
        context: Context,
        enabled: Boolean,
    ) {
        OfferwallClient.setAndroidDeviceIdEnabled(context, enabled)
    }

    /**
     * Returns whether the Android Device ID will be included in the offerwall URL.
     *
     * Reads the persisted value on the first call so the result is accurate even
     * before [setAndroidDeviceIdEnabled] has been called in the current process.
     *
     * @param context Any [Context]; the application context is used internally.
     */
    fun isAndroidDeviceIdEnabled(context: Context): Boolean = OfferwallClient.isAndroidDeviceIdEnabled(context)

    private fun initialize() {
        client =
            OfferwallClient
                .Builder()
                .withSettings(getSettings())
                .build()
    }

    fun connect(callback: IOfferwallClientConnectCallback) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.N) {
            callback.onFailure(XOError("Xsolla Offerwall SDK requires API level 24 or above"))
            return
        }
        if (client == null) {
            initialize()
        }
        client?.connect(callback)
    }

    /** Returns the privacy policy singleton for configuring GDPR, COPPA, and CCPA values. */
    fun getPrivacyPolicy(): XOPrivacyPolicy = XOPrivacyPolicy

    fun isReady(): Boolean = client != null && client!!.isReady()

    fun show(
        activity: Activity,
        placementId: String,
        customParams: Map<String, String>? = null,
        callback: IOfferwallOpenCallback,
    ) {
        if (client == null) {
            callback.onError(XOError("Xsolla Offerwall SDK Not Initialised"))
            return
        } else if (client?.isReady() == true) {
            client?.open(activity, placementId, customParams, callback)
        } else {
            callback.onError(XOError("Xsolla Offerwall SDK Not Ready"))
        }
    }
}
