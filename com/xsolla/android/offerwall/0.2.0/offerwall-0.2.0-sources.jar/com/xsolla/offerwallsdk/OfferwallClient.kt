package com.xsolla.offerwallsdk

import android.app.Activity
import android.content.Context
import android.os.Build
import android.util.DisplayMetrics
import androidx.core.content.edit
import androidx.core.net.toUri
import com.xsolla.offerwallsdk.util.DeviceIdProvider
import com.xsolla.offerwallsdk.util.Logger
import com.xsolla.offerwallsdk.util.MainThreadScheduler
import java.util.Locale
import java.util.TimeZone

internal class OfferwallClient private constructor(
    private var settings: XOSettings,
) {
    /** A lock used to synchronize the state of the client between threads. */
    private val lock = Any()

    @Volatile
    private var state: OfferwallClientState = OfferwallClientState.Disconnected

    private val webview = OfferwallWebViewEmbedded

    init {
        Logger.setLevel(settings.logLevel)
    }

    internal fun connect(callback: IOfferwallClientConnectCallback) {
        synchronized(lock) {
            if (isReady()) {
                Logger.warn("Client has already been connected")

                MainThreadScheduler.schedule {
                    callback.onSuccess()
                }
            } else if (state == OfferwallClientState.Disconnected) {
                Logger.info("Client has started the connection process")
                // Advance to Connecting immediately inside the lock so that any concurrent
                // connect() call observes a non-Disconnected state and does not enter this
                // branch a second time before the main-thread lambda runs.
                state = OfferwallClientState.Connecting

                MainThreadScheduler.schedule {
                    state = OfferwallClientState.Connected(webview)
                    callback.onSuccess()
                }
            }
        }
    }

    @JvmOverloads
    fun open(
        activity: Activity,
        placementId: String,
        customParams: Map<String, String>? = null,
        callback: IOfferwallOpenCallback,
    ) {
        if (state !is OfferwallClientState.Connected) {
            MainThreadScheduler.schedule {
                callback.onError(
                    XOError(
                        "Offerwall cannot be opened because the client is either still connecting, disconnected or closed",
                    ),
                )
            }
            return
        }

        if (placementId.isBlank()) {
            MainThreadScheduler.schedule {
                callback.onError(XOError("Opening offerwall requires a valid placement ID"))
            }
            return
        }

        val userId = XsollaOfferwallSdk.getUserId()
        if (userId.isBlank()) {
            MainThreadScheduler.schedule {
                callback.onError(XOError("Opening offerwall requires a valid user ID"))
            }
            return
        }

        Logger.info("Opening an offerwall (placement_id=$placementId user_id=$userId)")

        // URL generation runs on a background thread: DeviceIdProvider.resolve() performs
        // IPC calls (advertising ID, App Set ID) that must not block the main Looper.
        // In particular, the App Set ID Task's completion is dispatched *via* the main
        // Looper, so blocking the main thread here would deadlock.
        java.util.concurrent.Executors.newSingleThreadExecutor().execute {
            loadAndroidDeviceIdEnabledIfNeeded(activity.applicationContext)
            val url = generateUrl(activity, placementId, userId, customParams)
            Logger.debug("Offerwall URL: $url")

            MainThreadScheduler.schedule {
                webview.open(
                    activity,
                    url,
                    settings,
                    object : IOfferwallWebViewCallback {
                        override fun onOpened() {
                            Logger.debug("Opened the offerwall webview")
                            MainThreadScheduler.schedule {
                                callback.onOpened()
                            }
                        }

                        override fun onClosed() {
                            Logger.debug("Closed the offerwall webview")
                            MainThreadScheduler.schedule {
                                callback.onClosed()
                            }
                        }

                        override fun onError(error: XOError) {
                            MainThreadScheduler.schedule {
                                callback.onError(error)
                            }
                        }
                    },
                )
            }
        }
    }

    private fun generateUrl(
        activity: Activity,
        placementId: String,
        userId: String,
        customParams: Map<String, String>? = null,
    ): String {
        val context = activity.applicationContext
        val deviceIds = DeviceIdProvider.resolve(context)

        val appVersion =
            try {
                context.packageManager.getPackageInfo(context.packageName, 0).versionName
            } catch (e: Exception) {
                Logger.warn(e, "Failed to retrieve app version")
                null
            }

        val screenDimensions =
            try {
                val metrics = DisplayMetrics()
                @Suppress("DEPRECATION")
                activity.windowManager.defaultDisplay.getRealMetrics(metrics)
                Pair(metrics.widthPixels, metrics.heightPixels)
            } catch (e: Exception) {
                Logger.warn(e, "Failed to retrieve screen dimensions")
                null
            }

        val url =
            BASE_URL
                .toUri()
                .buildUpon()
                .appendPath(placementId)
                .appendQueryParameter("gamer_id", userId)
                .appendQueryParameter("platform", "android")
                .appendQueryParameter("sdk_version", BuildConfig.LIBRARY_VERSION)
                .appendQueryParameter("device_model", Build.MODEL)
                .appendQueryParameter("device_manufacturer", Build.MANUFACTURER)
                .appendQueryParameter("os_version", Build.VERSION.RELEASE)
                .appendQueryParameter("language", Locale.getDefault().toLanguageTag())
                .appendQueryParameter("timezone", TimeZone.getDefault().id)
                .appendQueryParameter("app_bundle", context.packageName)
                .apply {
                    appVersion?.let { appendQueryParameter("app_version", it) }
                    screenDimensions?.let { (w, h) ->
                        appendQueryParameter("screen_width", w.toString())
                        appendQueryParameter("screen_height", h.toString())
                    }
                    customParams?.forEach { (key, value) ->
                        appendQueryParameter(key, value)
                    }
                    if (androidDeviceIdEnabled) {
                        deviceIds.androidId?.let { appendQueryParameter("device_id", it) }
                    }
                    deviceIds.advertisingId?.let { appendQueryParameter("advertising_id", it) }
                    deviceIds.appSetId?.let { appendQueryParameter("developer_device_id", it) }
                    XsollaOfferwallSdk.getPrivacyPolicy().let { privacy ->
                        privacy.subjectToGDPR?.let {
                            appendQueryParameter(
                                "gdpr_applicable",
                                if (it) "1" else "0",
                            )
                        }
                        privacy.userConsent?.let { appendQueryParameter("user_consent", it) }
                        privacy.belowConsentAge?.let {
                            appendQueryParameter(
                                "below_consent_age",
                                if (it) "1" else "0",
                            )
                        }
                        privacy.usPrivacy?.let { appendQueryParameter("us_privacy", it) }
                    }
                }.build()
        return url.toString()
    }

    fun isReady(): Boolean = state is OfferwallClientState.Connected

    class Builder {
        private var settings: XOSettings? = null

        fun withSettings(settings: XOSettings) =
            apply {
                this.settings = settings
            }

        fun build(): OfferwallClient {
            require(settings != null) {
                "Offerwall client settings are missing"
            }

            return OfferwallClient(settings!!)
        }
    }

    companion object {
        private const val BASE_URL = "https://quests.xsolla.com/offerwall/"

        // -------------------------------------------------------------------------
        // Android Device ID opt-in
        // Stored at class level so the setting can be applied before a client
        // instance is created (i.e. before connect() is called).
        // -------------------------------------------------------------------------

        private const val PREFS_NAME = "xsolla_offerwall_sdk"
        private const val KEY_ANDROID_DEVICE_ID_ENABLED = "android_device_id_enabled"

        /** In-memory value; authoritative once the preference has been loaded. */
        @Volatile internal var androidDeviceIdEnabled: Boolean = false
            private set

        /**
         * Set to `true` once [setAndroidDeviceIdEnabled] is called *or* the
         * persisted preference has been read, so that the prefs file is only
         * opened once per process lifetime.
         */
        @Volatile private var androidDeviceIdPrefLoaded: Boolean = false

        /**
         * Controls whether the Android Device ID (`Settings.Secure.ANDROID_ID`) is
         * included as the `device_id` query parameter in the offerwall URL.
         *
         * Defaults to `false`. The setting is persisted across app sessions via
         * [android.content.SharedPreferences] and may be called **before or after**
         * a client instance is created.
         *
         * @param context Any [Context]; the application context is used internally.
         * @param enabled `true` to include the Android Device ID; `false` to omit it.
         */
        internal fun setAndroidDeviceIdEnabled(
            context: Context,
            enabled: Boolean,
        ) {
            context.applicationContext
                .getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
                .edit {
                    putBoolean(KEY_ANDROID_DEVICE_ID_ENABLED, enabled)
                }
            androidDeviceIdEnabled = enabled
            androidDeviceIdPrefLoaded = true
        }

        /**
         * Reads the persisted preference on the first call; subsequent calls return
         * the cached in-memory value without hitting disk. Safe to call from any thread.
         */
        internal fun loadAndroidDeviceIdEnabledIfNeeded(context: Context) {
            if (!androidDeviceIdPrefLoaded) {
                androidDeviceIdEnabled =
                    context
                        .getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
                        .getBoolean(KEY_ANDROID_DEVICE_ID_ENABLED, false)
                androidDeviceIdPrefLoaded = true
            }
        }

        /**
         * Returns whether the Android Device ID will be included in the offerwall URL.
         *
         * Reads the persisted value on the first call so the result is accurate
         * even before [setAndroidDeviceIdEnabled] has been called in the current
         * process.
         *
         * @param context Any [Context]; the application context is used internally.
         */
        internal fun isAndroidDeviceIdEnabled(context: Context): Boolean {
            loadAndroidDeviceIdEnabledIfNeeded(context.applicationContext)
            return androidDeviceIdEnabled
        }
    }
}
